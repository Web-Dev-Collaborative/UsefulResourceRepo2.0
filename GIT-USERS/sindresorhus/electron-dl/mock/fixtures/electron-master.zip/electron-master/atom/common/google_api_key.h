// Copyright (c) 2014 GitHub, Inc.
// Use of this source code is governed by the MIT license that can be
// found in the LICENSE file.

#ifndef ATOM_COMMON_GOOGLE_API_KEY_H_
#define ATOM_COMMON_GOOGLE_API_KEY_H_

#ifndef GOOGLEAPIS_ENDPOINT
#define GOOGLEAPIS_ENDPOINT \
    "https://www.googleapis.com/geolocation/v1/geolocate?key="
#endif

#ifndef GOOGLEAPIS_API_KEY
#define GOOGLEAPIS_API_KEY "AIzaSyAQfxPJiounkhOjODEO5ZieffeBv6yft2Q"
#endif

#endif  // ATOM_COMMON_GOOGLE_API_KEY_H_
